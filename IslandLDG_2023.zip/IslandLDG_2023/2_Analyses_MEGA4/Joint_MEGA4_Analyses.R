############################
###### LOAD PACKAGES #######
############################

library(mgcv); library(gridExtra); library(betareg); library(MASS); library(lme4); library(lmerTest); library(lsmeans); library(ggeffects); library(spdep); library(ggplot2); library(ncf); library(ape); library(sjPlot); library(gridExtra); library(MuMIn); library(tidyverse); library(maps); library(sf); library(tidyverse); library(relaimpo)
options(na.action = "na.fail")

############################
###### LOAD FUNCTIONS ######
############################

#overdispersion function
Check.disp <- function(mod,dat) {
  N <- nrow(dat)
  p <- length(coef(mod))
  E1 <- resid(mod, type = "pearson")
  Dispersion <- sum(E1^2)/ (N-p)
  return(Dispersion)
}

#RAC function
Spat.cor <- function(mod,dat, dist) {
  coords <- cbind(dat$longitude, dat$latitude)
  matrix.dist = as.matrix(dist(cbind(dat$longitude, dat$latitude)))
  matrix.dist[1:10, 1:10]
  matrix.dist.inv <- 1/matrix.dist
  matrix.dist.inv[1:10, 1:10]
  diag(matrix.dist.inv) <- 0
  matrix.dist.inv[1:10, 1:10]
  myDist = dist
  rac <- autocov_dist(resid(mod), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat = T)
  return(rac)
}

#RAC function when locations repeat (shift latlon)
Spat.cor.rep <- function(mod,dat, dist) {
  coords <- cbind(dat$longitude, dat$latitude) + matrix(runif(2*nrow(dat), 0, 0.00001), nrow = nrow(dat), ncol = 2)
  matrix.dist = as.matrix(dist(cbind(dat$longitude, dat$latitude)))
  matrix.dist[1:10, 1:10]
  matrix.dist.inv <- 1/matrix.dist
  matrix.dist.inv[1:10, 1:10]
  diag(matrix.dist.inv) <- 0
  matrix.dist.inv[1:10, 1:10]
  myDist = dist
  rac <- autocov_dist(resid(mod), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat = T)
  return(rac)
}

############################
######## READ DATA #########
############################

debt <- readRDS("data/debt_native_myc_latitude_data_2023.RDS")

mycdat <- readRDS("data/GAMexp_native_myc_latitude_data_2023.RDS") %>% select("entity_ID","propAM_exp", "propEM_exp", "propORC_exp") %>% rename(AM.ml = propAM_exp, EM.ml = propEM_exp, ORC.ml = propORC_exp)
nfixdat <- readRDS("data/GAMexp_native_nfix_latitude_data_2023.RDS") %>% select("entity_ID","propnfix_exp") %>% rename(nfix.ml = propnfix_exp)
polldat <- readRDS("data/GAMexp_native_poll_latitude_data_2023.RDS") %>% select("entity_ID","propb_exp") %>% rename(poll.ml = propb_exp)

# join these:
dat <- debt %>%
  full_join(mycdat, by = "entity_ID") %>%
  full_join(nfixdat, by = "entity_ID") %>%
  full_join(polldat, by = "entity_ID") %>%
  #make sum biotic drivers
  #choose one
  #more conservative: average % of species that exhibit one of these syndromes
  mutate(biotic.ml = (nfix.ml + poll.ml + AM.ml)/3) %>%
  #probability that one of 3 independent events occurred: https://www.omnicalculator.com/statistics/probability-three-events
  #mutate(biotic.ml = nfix.ml + poll.ml + AM.ml - nfix.ml * poll.ml - nfix.ml * AM.ml - poll.ml * AM.ml + nfix.ml * poll.ml * AM.ml) %>%
  #area, dist, elev_range already scaled and log transformed
  mutate(abslatitude = as.vector(scale(abslatitude)), nfix.ml = as.vector(scale(log10((nfix.ml)+.01))),poll.ml = as.vector(scale(log10((poll.ml)+.01))),
       AM.ml = as.vector(scale(log10((AM.ml)+.01))), EM.ml = as.vector(scale(log10((EM.ml)+.01))), ORC.ml = as.vector(scale(log10((ORC.ml)+.01))),
       biotic.ml = as.vector(scale(log10((biotic.ml)+.01)))) %>%
  #mutate(abslatitude - as.vector(scale(abslatitude)), nfix.ml = as.vector(scale(logit(nfix.ml))),poll.ml = as.vector(scale(logit(poll.ml))),
  #     AM.ml = as.vector(scale(logit(AM.ml))), EM.ml = as.vector(scale(logit(EM.ml))), ORC.ml = as.vector(scale(logit(ORC.ml)))) 
  drop_na() %>%
  mutate(sprichdiff = ifelse(sprichdiff <0,0, sprichdiff))

dat.br <- dat %>% filter(Tdebt > 0)

############################
######## VAR CORR ##########
############################

corr.vars <- dat %>%
  select(c("abslatitude","dist","area","elev_range","temp","prec","poll.ml", "nfix.ml","AM.ml","EM.ml", "ORC.ml"))                              
corr.vars <- dat %>%
  select(c("abslatitude","dist","area","elev_range","prec","biotic.ml"))                              
corr.mat <- as.matrix(cor(corr.vars))               

############################
######## TDEBT MODS ########
############################

# no interactions
Tdebt.mod <- glm(Tdebt ~ abslatitude + area + dist + elev_range + prec + biotic.ml, weights = sprich_exp, data = dat) 
rac <- Spat.cor.rep(Tdebt.mod, dat, 2000)
Tdebt.mod.rac <- glm(Tdebt ~ abslatitude + area + dist + elev_range +  prec + biotic.ml + rac, weights = sprich_exp, data = dat) 
summary(Tdebt.mod.rac)
calc.relimp(Tdebt.mod.rac)

# no interactions w/ lat betareg
#Tdebt.mod <- glm(Tdebt ~ abslatitude + area + dist + elev_range +  prec + biotic.ml, weights = sprich_exp, data = dat.br) 
#rac <- Spat.cor.rep(Tdebt.mod, dat.br, 2000)
#Tdebt.mod.rac <- glm(Tdebt ~ abslatitude + area + dist + elev_range +  prec + biotic.ml + rac, weights = sprich_exp, data = dat.br) 
#summary(Tdebt.mod.rac)
#calc.relimp(Tdebt.mod.rac)

# interactions w/ lat
# ALL NS
Tdebt.mod <- glm(Tdebt ~ abslatitude*area + abslatitude*dist + abslatitude*elev_range + abslatitude*prec + abslatitude*biotic.ml, weights = sprich_exp, data = dat) 
rac <- Spat.cor.rep(Tdebt.mod, dat, 2000)
Tdebt.mod.rac <- glm(Tdebt ~ abslatitude*area + abslatitude*dist + abslatitude*elev_range + + abslatitude*prec + abslatitude*biotic.ml + rac, weights = sprich_exp, data = dat) 
summary(Tdebt.mod.rac) 
calc.relimp(Tdebt.mod.rac)

# interactions w/ lat betareg
#Tdebt.mod <- betareg(Tdebt ~ abslatitude*area + abslatitude*dist + abslatitude*elev_range + + abslatitude*prec + abslatitude*biotic.ml, weights = sprich_exp, data = dat.br) 
#rac <- Spat.cor.rep(Tdebt.mod, dat.br, 2000)
#Tdebt.mod.rac <- betareg(Tdebt ~ abslatitude*area + abslatitude*dist + abslatitude*elev_range + + abslatitude*prec + abslatitude*biotic.ml + rac, weights = sprich_exp, data = dat.br) 
#summary(Tdebt.mod.rac) 
#calc.relimp(Tdebt.mod.rac)

datplot <- ggeffect(Tdebt.mod.rac, terms = c("biotic.ml"), type= "re")
plot(datplot)

# check assumptions
par(mfrow = c(2,2))
plot(Tdebt.mod.rac)
vif(Tdebt.mod.rac)

# Model averages
#create models with all possible combinations of predictors
dredged_models <- dredge(Tdebt.mod.rac)

#perform AIC model averaging, only considering models with AIC values within 4 of the best model
averaged_model_results <- model.avg(dredged_models, delta < 4, fit = TRUE)

#examine results
summary(averaged_model_results)

############################
##### SPRICH DIFF MODS #####
############################

# no beta reg since values are not 0-1, but 0 to many

# no interactions
sprichdiff.mod <- glm(sprichdiff ~ abslatitude + area + dist + elev_range +  prec + biotic.ml, data = dat) 
rac <- Spat.cor.rep(sprichdiff.mod, dat, 2000)
sprichdiff.mod.rac <- glm(sprichdiff ~ abslatitude + area + dist + elev_range +  prec + biotic.ml + rac, data = dat) 
summary(sprichdiff.mod.rac)
calc.relimp(sprichdiff.mod.rac)

# FINAL MODEL
# interactions w/ lat
# no elev range (ns in above model model averaging)
sprichdiff.mod <- glm(sprichdiff ~ abslatitude*area + abslatitude*dist + abslatitude*prec + abslatitude*biotic.ml , data = dat) 
rac <- Spat.cor.rep(sprichdiff.mod, dat, 2000)
sprichdiff.mod.rac <- glm(sprichdiff ~ abslatitude*area + abslatitude*dist  + abslatitude*prec + abslatitude*biotic.ml+ rac, data = dat) 
summary(sprichdiff.mod.rac) 
#calc.relimp(sprichdiff.mod.rac)

datplot <- ggeffect(sprichdiff.mod.rac, terms = c("biotic.ml","abslatitude"), type = "re")
datplot <- ggeffect(sprichdiff.mod.rac, terms = c("dist","abslatitude"), type = "re")
datplot <- ggeffect(sprichdiff.mod.rac, terms = c("area","abslatitude"), type = "re")
plot(datplot)

# check assumptions
par(mfrow = c(2,2))
plot(sprichdiff.mod.rac)
vif(sprichdiff.mod.rac)

# Model averages
#create models with all possible combinations of predictors
dredged_models <- dredge(sprichdiff.mod.rac)

#perform AIC model averaging, only considering models with AIC values within 4 of the best model
averaged_model_results <- model.avg(dredged_models, delta < 4, fit = TRUE)

#examine results
summary(averaged_model_results)

vcov <- vcov(averaged_model_results)

############################
######## MAKE PLOTS ########
############################

#####################################
###### Forest plots (relimp) ########
#####################################

mod.dat <- calc.relimp(sprichdiff.mod.rac)$lmg %>% as.data.frame() %>%
  rownames_to_column(., var = "variable") %>%
  filter(! variable=="rac") %>%
  mutate(variable = case_when(variable=="abslatitude" ~ "Absolute latitude",
                               variable=="area" ~ "Area", 
                               variable=="biotic.ml" ~ "Biotic",
                               variable=="dist" ~ "Distance",
                               variable=="prec" ~ "Precipitation",
                               variable=="elev_range" ~ "Elevation range"))

colnames(mod.dat)<-c("variable", "rel.imp")

mod.dat.ordered <- mod.dat %>% mutate(variable = fct_reorder(variable, rel.imp))

forest.plot <-
  ggplot(data=mod.dat.ordered, aes(x=variable, y=rel.imp, ymin=rel.imp, ymax=rel.imp)) +
  geom_pointrange(alpha = 0.8) + 
  #geom_hline(yintercept=0, lty=2, color='darkgrey') +  # add a dotted line at x=1 after flip
  coord_flip() +  # flip coordinates (puts labels on y axis)
  xlab(" ") + ylab("Variable Importance") +
  theme_classic(base_size = 20)+
  theme(legend.position = "none")+
  theme(axis.text.y = element_text(angle = 0))

png("figures/sprichdiff_relimp_forestplot.jpg", width = 6, height = 6, units = 'in', res = 300)
forest.plot
dev.off()

#####################################
##### Forest plots (estimates) ######
#####################################

mod.dat <- summary(averaged_model_results)$coefmat.full %>% as.data.frame() %>%
  mutate(variable = rownames(.)) %>%
  filter(! variable=="(Intercept)") %>%
  filter(! variable=="rac") %>%
  mutate(variable = case_when(variable=="abslatitude" ~ "Absolute latitude",
                              variable=="area" ~ "Area", 
                              variable=="biotic.ml" ~ "Biotic",
                              variable=="dist" ~ "Distance",
                              variable=="prec" ~ "Precipitation",
                              variable=="elev_range" ~ "Elevation range")) %>%
  filter(!is.na(variable)) 

colnames(mod.dat)<-c("est", "std.err","adjusted.se","zval","pval", "variable")

mod.dat.ordered <- mod.dat %>% mutate(variable = fct_reorder(variable, est))

forest.plot <-
  ggplot(data=mod.dat.ordered, aes(x=variable, y=est, ymin=est-std.err, ymax=est+std.err), fill = "darkgrey") +
  geom_pointrange(alpha = 0.8) + 
  geom_hline(yintercept=0, lty=2, color='darkgrey') +  # add a dotted line at x=1 after flip
  coord_flip() +  # flip coordinates (puts labels on y axis)
  xlab(" ") + ylab("Model Estimate") +
  theme_classic(base_size = 18)+
  theme(legend.position = "none")+
  theme(axis.text.y = element_text(angle = 45))

png("figures/sprichdiff_dredgeest_forestplot.jpg", width = 7, height = 6, units = 'in', res = 300)
forest.plot
dev.off()

#####################################
##### Forest plots (estimates) ######
######### With interactions #########
#####################################

mod.dat <- summary(averaged_model_results)$coefmat.full %>% as.data.frame() %>%
  mutate(variable = rownames(.)) %>%
  filter(! variable=="(Intercept)") %>%
  filter(! variable=="rac") %>%
  mutate(variable = case_when(variable=="abslatitude" ~ "Absolute latitude",
                              variable=="area" ~ "Area", 
                              variable=="biotic.ml" ~ "Biotic",
                              variable=="dist" ~ "Distance",
                              variable=="prec" ~ "Precipitation",
                              variable=="elev_range" ~ "Elevation range")) %>%
  filter(!is.na(variable)) 

colnames(mod.dat)<-c("est", "std.err","adjusted.se","zval","pval", "variable")

mod <- sprichdiff.mod.rac # use interaction model
cut_tol <- 0.05

# determine low and high lat 
abslatitude.minmax <- data.frame(abslatitude = quantile(mod$data$abslatitude, c(cut_tol,0.5,1-cut_tol)), level =c ("low","med","high")) 

# predict high and low area

#model = coefarea*(area) + coefarea_lat(area*abslat)

#coefficient = (coefarea + abslat*coefarea_abslat)
#variance = var(area) + ablat^2*var(area_lat) + 2*abslat*cov(area,area_lat)
#standard error = sqrt(variance)

#coef_area = -473.95387
#coef_area_lat = 106.86981

#var area = 1081.8634757
#var area_lat = 1068.8511987
#cov area_area_lat = 88.3003682

C1 <- -473.95387
C12 <- 106.86981

V1 <- 1081.8634757
V12 <- 1068.8511987
CV12 <- 88.3003682

area.coef.low <- C1 + abslatitude.minmax[1,1]*C12
area.var.low <- V1 + (abslatitude.minmax[1,1])^2*V12 +2*abslatitude.minmax[1,1]*CV12
area.stderr.low <- sqrt(abs(area.var.low))

area.coef.med <- C1 + abslatitude.minmax[2,1]*C12
area.var.med <- V1 + (abslatitude.minmax[2,1])^2*V12 +2*abslatitude.minmax[2,1]*CV12
area.stderr.med <- sqrt(abs(area.var.med))

area.coef.high <- C1 + abslatitude.minmax[3,1]*C12
area.var.high <- V1 + (abslatitude.minmax[3,1])^2*V12 +2*abslatitude.minmax[3,1]*CV12
area.stderr.high <- sqrt(abs(area.var.high))

# predict high and low dist

#coef_dist = 582.41137
#coef_dist_lat = -232.47661

#var dist = 8153.5153633
#var dist_lat = 9383.639261
#cov dist_dist_lat = -1007.7843250

C1 <- 582.41137
C12 <- -232.47661
  
V1 <- 8153.5153633
V12 <- 9383.639261
CV12 <- -1007.7843250

dist.coef.low <- C1 + abslatitude.minmax[1,1]*C12
dist.var.low <- V1 + (abslatitude.minmax[1,1])^2*V12 +2*abslatitude.minmax[1,1]*CV12
dist.stderr.low <- sqrt(abs(dist.var.low))

dist.coef.med <- C1 + abslatitude.minmax[2,1]*C12
dist.var.med <- V1 + (abslatitude.minmax[2,1])^2*V12 +2*abslatitude.minmax[2,1]*CV12
dist.stderr.med <- sqrt(abs(dist.var.med))

dist.coef.high <- C1 + abslatitude.minmax[3,1]*C12
dist.var.high <- V1 + (abslatitude.minmax[3,1])^2*V12 +2*abslatitude.minmax[3,1]*CV12
dist.stderr.high <- sqrt(abs(dist.var.high))

# predict high and low biotic.ml

#coef_biotic.ml = 605.04905
#coef_biotic.ml_lat = -187.98127

#var biotic.ml = 4333.1130002
#var biotic.ml_lat = 916.4754238
#cov biotic.ml_biotic.ml_lat = -1565.4551739

C1 <- 605.04905
C12 <- -187.98127
  
V1 <- 4333.1130002
V12 <- 916.4754238
CV12 <- -1565.4551739

biotic.ml.coef.low <- C1 + abslatitude.minmax[1,1]*C12
biotic.ml.var.low <- V1 + (abslatitude.minmax[1,1])^2*V12 +2*abslatitude.minmax[1,1]*CV12
biotic.ml.stderr.low <- sqrt(abs(biotic.ml.var.low))

biotic.ml.coef.med <- C1 + abslatitude.minmax[2,1]*C12
biotic.ml.var.med <- V1 + (abslatitude.minmax[2,1])^2*V12 +2*abslatitude.minmax[2,1]*CV12
biotic.ml.stderr.med <- sqrt(abs(biotic.ml.var.med))

biotic.ml.coef.high <- C1 + abslatitude.minmax[3,1]*C12
biotic.ml.var.high <- V1 + (abslatitude.minmax[3,1])^2*V12 +2*abslatitude.minmax[3,1]*CV12
biotic.ml.stderr.high <- sqrt(abs(biotic.ml.var.high))

# join together

mod.dat <- mod.dat %>% select("est","std.err","variable") %>% mutate(latlevel="mean")
mod.dat <- mod.dat  %>% add_row(est = area.coef.low, std.err = area.stderr.low, variable = "Area",latlevel ="low")
#mod.dat <- mod.dat  %>% add_row(est = area.coef.med, std.err = area.stderr.med, variable = "Area",latlevel ="med")
mod.dat <- mod.dat  %>% add_row(est = area.coef.high, std.err = area.stderr.high, variable = "Area",latlevel ="high")
mod.dat <- mod.dat  %>% add_row(est = dist.coef.low, std.err = dist.stderr.low, variable = "Distance",latlevel ="low")
#mod.dat <- mod.dat  %>% add_row(est = dist.coef.med, std.err = dist.stderr.med, variable = "Distance",latlevel ="med")
mod.dat <- mod.dat  %>% add_row(est = dist.coef.high, std.err = dist.stderr.high, variable = "Distance",latlevel ="high")
mod.dat <- mod.dat  %>% add_row(est = biotic.ml.coef.low, std.err = biotic.ml.stderr.low, variable = "Biotic",latlevel ="low")
#mod.dat <- mod.dat  %>% add_row(est = biotic.ml.coef.med, std.err = biotic.ml.stderr.med, variable = "Biotic",latlevel ="med")
mod.dat <- mod.dat  %>% add_row(est = biotic.ml.coef.high, std.err = biotic.ml.stderr.high, variable = "Biotic",latlevel ="high")

mod.dat <- mod.dat %>% mutate(latlevel= as.factor(latlevel)) %>% mutate(variable = as.factor(variable))
levels(mod.dat$latlevel)
levels(mod.dat$variable)

#relevel
mod.dat$latlevel <- factor(mod.dat$latlevel, levels = c("low", "mean", "high"))
mod.dat$variable <- factor(mod.dat$variable, levels = c("Absolute latitude","Precipitation","Biotic","Distance","Area"))

# create a custom color scale
colScale <- scale_colour_manual(values = c("gray10","dimgray", "darkgrey"))
fillScale <- scale_fill_manual(values = c("gray10","dimgray", "darkgrey"))

forest.plot <-
  ggplot(data=mod.dat , aes(x=variable, y=est, ymin=est-std.err, ymax=est+std.err,fill = latlevel, color = latlevel), fill = latlevel, color = latlevel) +
  geom_pointrange(alpha = 0.8, size = 1.25) + 
  geom_hline(yintercept=0, lty=2, color='darkgrey') +  # add a dotted line at x=1 after flip
  coord_flip() +  # flip coordinates (puts labels on y axis)
  xlab(" ") + ylab("Model Estimate") +
  theme_classic(base_size = 38) +
  theme(legend.position = 'none') +
  theme(legend.justification=c(1,1), legend.position=c(1,1))+
  guides(fill = FALSE) +
  guides(color = guide_legend(title = "Latitude", override.aes = list(fill = NA, linetype = c(0, 0, 0))))+
  colScale +
  fillScale+
  theme(axis.text.y = element_text(angle = 45))

png("figures/sprichdiff_dredgeest_forestplot.jpg", width = 12, height = 10, units = 'in', res = 300)
forest.plot
dev.off()

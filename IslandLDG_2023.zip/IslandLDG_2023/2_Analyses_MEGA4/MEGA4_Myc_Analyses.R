############################
###### LOAD PACKAGES #######
############################

library(mgcv); library(gridExtra); library(betareg); library(MASS); library(lme4); library(lmerTest); library(lsmeans); library(ggeffects); library(spdep); library(ggplot2); library(ncf); library(ape); library(sjPlot); library(gridExtra); library(MuMIn); library(tidyverse); library(maps); library(sf); library(tidyverse); library(car);library(viridis) 
options(na.action = "na.fail")

############################
###### LOAD FUNCTIONS ######
############################

#overdispersion function
Check.disp <- function(mod,dat) {
  N <- nrow(dat)
  p <- length(coef(mod))
  E1 <- resid(mod, type = "pearson")
  Dispersion <- sum(E1^2)/ (N-p)
  return(Dispersion)
}

#RAC function
Spat.cor <- function(mod,dat, dist) {
  coords <- cbind(dat$longitude, dat$latitude)
  matrix.dist = as.matrix(dist(cbind(dat$longitude, dat$latitude)))
  matrix.dist[1:10, 1:10]
  matrix.dist.inv <- 1/matrix.dist
  matrix.dist.inv[1:10, 1:10]
  diag(matrix.dist.inv) <- 0
  matrix.dist.inv[1:10, 1:10]
  myDist = dist
  rac <- autocov_dist(resid(mod), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat = T)
  return(rac)
}

#RAC function when locations repeat (shift latlon)
Spat.cor.rep <- function(mod,dat, dist) {
  coords <- cbind(dat$longitude, dat$latitude) + matrix(runif(2*nrow(dat), 0, 0.00001), nrow = nrow(dat), ncol = 2)
  matrix.dist = as.matrix(dist(cbind(dat$longitude, dat$latitude)))
  matrix.dist[1:10, 1:10]
  matrix.dist.inv <- 1/matrix.dist
  matrix.dist.inv[1:10, 1:10]
  diag(matrix.dist.inv) <- 0
  matrix.dist.inv[1:10, 1:10]
  myDist = dist
  rac <- autocov_dist(resid(mod), coords, nbs = myDist, type = "inverse", zero.policy = TRUE, style = "W", longlat = T)
  return(rac)
}

############################
######## LDG MODELS ########
############################

############################
######## READ DATA #########
############################

dat <-  readRDS("data/native_myc_latitude_data_2023.RDS") %>%
  filter(!entity_class == "undetermined") %>%                                        
  select(c("entity_ID","entity_class","sprich","latitude","longitude","geology", "area",  "CHELSA_annual_mean_Temp", "CHELSA_annual_Prec",
           "AM","EM","ORC","NM")) %>%
  rename(temp = CHELSA_annual_mean_Temp, prec = CHELSA_annual_Prec) %>%
  mutate(entity_class2 = case_when(geology == "dev" ~ "Oceanic",                      
                                   geology == "nondev" ~ "Non-oceanic",
                                   entity_class =="Mainland" ~ "Mainland")) %>%
  select(-geology) %>%          
  filter(area > 6) %>% # based on paper Patrick shared
  mutate(abslatitude = abs(latitude)) %>%                                             
  mutate(abslatitude = as.vector(abslatitude)) %>% 
  #mutate(elev_range = ifelse(elev_range==0,1, elev_range)) %>%                                   
  #mutate(elev_range = ifelse(is.na(elev_range),1, elev_range)) %>%
  #for models only; remove for figs:
  mutate(area = as.vector(scale(log10((area)+.01))), 
         temp = as.vector(scale(temp)), prec = as.vector(scale(log10((prec)+.01)))) %>%
  filter(!entity_class2 == "Non-oceanic") %>%
  drop_na()

############################
######## CREATE MAP ########
############################

# read world data
world <- map_data("world")

dat.ml <- dat %>% filter(entity_class2 =="Mainland")
dat.oi <- dat %>% filter(entity_class2 =="Oceanic")

# write out
png("figures/Landtype_map.jpg", width = 8, height = 5, units = 'in', res = 300)
ggplot()+
  geom_polygon(data = world, aes(x = long, y = lat, group = group), fill = "gray88", alpha = 0.5) +
  geom_point(data = dat.ml, 
             aes(x = longitude, y = latitude, color = factor(sprich), fill = factor(sprich)),  
             pch = 16, size = 2, alpha = 0.7) +
  geom_point(data = dat.oi, 
             aes(x = longitude, y = latitude, color = factor(sprich), fill = factor(sprich)),  
             pch = 16, size = 2, alpha = 0.7) +
  scale_color_viridis(discrete=TRUE) +
  xlab("") + ylab ("") +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5,size = 30)) +
  coord_sf(ylim = c(-65, 85), xlim = c(-200, 200), expand = FALSE) +
  theme(axis.line = element_blank(), axis.ticks = element_blank(), legend.position = "none",
        axis.text.x = element_blank(), axis.title.x = element_blank())#,
#axis.text.y = element_blank(), axis.title.y = element_blank() #, 
#panel.background = element_blank(), panel.border = element_blank(), panel.grid.major = element_blank(),
#panel.grid.minor = element_blank(), plot.background = element_blank())
dev.off()

############################
######## VAR CORR ##########
############################

corr.vars <- dat %>%
  select(c("abslatitude","area","temp","prec"))                              
corr.mat <- as.matrix(cor(corr.vars))                  

############################
######### LAND TYPE ########
############################

m1 <- glm.nb(sprich ~ entity_class2*abslatitude + area  + prec, data = dat) 
rac <- Spat.cor(m1,dat,2000)
m1.rac <- glm.nb(sprich ~ entity_class2*abslatitude + area  + prec + rac , data = dat) 
summary(m1.rac)

# check assumptions
par(mfrow = c(2,2))
plot(m1.rac)
Check.disp(m1.rac, dat)
vif(m1.rac)

############################
########### PLOT ###########
##### LAT BY LAND TYPE #####
############################

new.dat.ml <- with(dat, expand.grid(abslatitude = seq(min(abslatitude), max(abslatitude), length = 100))) %>% 
  mutate(entity_class2 = "Mainland", rac = mean(rac), area = mean(dat$area), prec = mean(dat$prec))
new.dat.oi <- with(dat, expand.grid(abslatitude = seq(min(abslatitude), max(abslatitude), length = 100))) %>% 
  mutate(entity_class2 = "Oceanic", rac = mean(rac), area = mean(dat$area), prec = mean(dat$prec))
#new.dat.noi <- with(dat, expand.grid(abslatitude = seq(min(abslatitude), max(abslatitude), length = 100))) %>% 
#  mutate(entity_class2 = "Non-oceanic", rac = mean(rac), area = mean(dat$area), prec = mean(dat$prec))
#new.dat <- rbind(new.dat.ml, new.dat.oi, new.dat.noi)
new.dat <- rbind(new.dat.ml, new.dat.oi)

pred.ml <- predict(m1.rac, newdata = new.dat.ml, type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude = new.dat.ml$abslatitude, entity_class2 = "Mainland")
pred.oi <- predict(m1.rac,newdata = new.dat.oi, type = "response", se = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude = new.dat.oi$abslatitude, entity_class2 = "Oceanic")
#pred.noi <- predict(m1.rac,newdata = new.dat.noi, type = "response", se = TRUE) %>%
#  as.data.frame() %>% 
#  mutate(abslatitude = new.dat.noi$abslatitude, entity_class2 = "Non-oceanic")
#pred.all <- rbind(pred.ml, pred.oi, pred.noi) 
pred.all <- rbind(pred.ml, pred.oi)

# create a custom color scale
colScale <- scale_colour_manual(values = c("darkseagreen3", "cyan4", "deepskyblue4"))
fillScale <- scale_fill_manual(values = c("darkseagreen3", "cyan4", "deepskyblue4"))

lat.landtype <- 
  ggplot(data = pred.all,aes(x = abslatitude, y = fit, color = entity_class2, fill = entity_class2))+
  geom_line() +
  geom_ribbon(aes(ymin = fit-se.fit, ymax = fit+se.fit), alpha = 0.5) + 
  #remove this for no point version:
  geom_point(data = dat, mapping = aes(x = abslatitude, y = sprich, color = factor(entity_class2)), alpha = 0.5, size = 5)+ 
  xlab("Absolute latitude") +
  ylab("Species richness") +
  theme_classic(base_size = 40)+
  ylim(0,2000) +
  colScale +
  fillScale +
  theme(legend.position = 'none') +
  theme(legend.justification=c(1,1), legend.position=c(1,1))+
  guides(fill = FALSE) +
  guides(color = guide_legend(title = "Land Type", override.aes = list(fill = NA, linetype = c(0, 0))))+
  theme(axis.text.x = element_text(size = 20),axis.text.y = element_text(angle = 45, size = 20))

# write out
png("figures/Myc_LatbyLandType.jpg", width = 10, height = 10, units = 'in', res = 300)
lat.landtype
dev.off()

############################
###### MAINLANDS ONLY ######
############################

dat.ml <- dat %>% filter(entity_class2 == "Mainland")
m1.ml <- glm.nb(sprich ~ abslatitude + area  + prec, data = dat.ml, control = glm.control(maxit = 500)) 
#m1.ml <- glm.nb(sprich ~ abslatitude + area  + prec + elev_range, data = dat.ml, control = glm.control(maxit = 500)) 
rac <- Spat.cor(m1.ml,dat.ml, 2000)
m1.ml.rac <- glm.nb(sprich ~ abslatitude + area  + prec + rac, data = dat.ml, control = glm.control(maxit = 500)) 
#m1.ml.rac <- glm.nb(sprich ~ abslatitude + area  + prec + elev_range + rac, data = dat.ml, control = glm.control(maxit = 500)) 
summary(m1.ml.rac)

# check assumptions
par(mfrow = c(2,2))
plot(m1.ml.rac)
Check.disp(m1.ml.rac,dat)
vif(m1.ml)

####################################
############ ISLAND TYPES ##########
####################################

############################
######## READ DATA #########
############################

dat2 <-  readRDS("data/native_myc_latitude_data_2023.RDS") %>%
  filter(!entity_class == "undetermined") %>%                                        
  select(c("entity_ID","entity_class","sprich","latitude","longitude","geology", "area", "elev_range", "dist", "CHELSA_annual_mean_Temp", "CHELSA_annual_Prec",   
           "AM","EM","ORC","NM")) %>%
  rename(temp = CHELSA_annual_mean_Temp, prec = CHELSA_annual_Prec) %>%
  mutate(entity_class2 = case_when(geology == "dev" ~ "Oceanic",                      
                                   geology == "nondev" ~ "Non-oceanic",
                                   entity_class =="Mainland" ~ "Mainland")) %>%
  select(-geology) %>%                                                              
  mutate(abslatitude = abs(latitude)) %>%                                             
  mutate(abslatitude = as.vector(abslatitude)) %>%    
  mutate(elev_range = ifelse(elev_range==0,1, elev_range)) %>%                                   
  mutate(elev_range = ifelse(is.na(elev_range),1, elev_range)) %>%
  filter(area > 6) %>% # based on paper Patrick shared
  #for models only; remove for figs:
  mutate(area = as.vector(scale(log10((area)+.01))), dist = as.vector(scale(log10((dist)+.01))), elev_range = as.vector(scale(log10((elev_range)+.01))),
         temp = as.vector(scale(temp)), prec = as.vector(scale(log10((prec)+.01)))) %>%
  #filter(!entity_class2 == "Non-oceanic") %>%
  drop_na() 

####################################
####### OCEANIC ISLANDS ONLY #######
############# N = 212 ##############
####################################

dat.o <- dat2 %>% filter(entity_class2 == "Oceanic")
m1.o <- glm.nb(sprich ~ abslatitude + area + dist + elev_range + prec, data = dat.o, control = glm.control(maxit = 500)) 
rac <- Spat.cor(m1.o,dat.o,2000)
m1.o.rac <- glm.nb(sprich ~ abslatitude + area + dist + elev_range + prec + rac , data = dat.o, control = glm.control(maxit = 500)) 
summary(m1.o.rac)

# check assumptions
par(mfrow = c(2,2))
plot(m1.o.rac)
Check.disp(m1.o.rac,dat.o)
vif(m1.o.rac)

####################################
##### NON- OCEANIC ISLANDS ONLY ####
############# N = 131 ##############
####################################

dat.no <- dat2 %>% filter(entity_class2 == "Non-oceanic")
m1.no <- glm.nb(sprich ~ abslatitude + area + dist + elev_range + prec, data = dat.no, control = glm.control(maxit = 500)) 
rac <- Spat.cor(m1.no,dat.no,2000)
m1.no.rac <- glm.nb(sprich ~ abslatitude + area + dist + elev_range + prec + rac , data = dat.no, control = glm.control(maxit = 500)) 
summary(m1.no.rac)

# check assumptions
par(mfrow = c(2,2))
plot(m1.no.rac)
Check.disp(m1.no.rac,dat.no)
vif(m1.no.rac)

############################
######## ML PREDICT ########
############################

############################
######### MAINLAND #########
############################

dat.ml <- dat %>% filter(entity_class2 == "Mainland")
gam.mod_sprich <- gam(sprich ~ s(abslatitude), family = nb(link = "log"), data = dat.ml) 
summary(gam.mod_sprich)

# check assumptions
gam.check(gam.mod_sprich)
Check.disp(gam.mod_sprich,dat)

pred_sprich <- predict.gam(gam.mod_sprich,type = "response", se = TRUE) 
pred_sprich <- data.frame("abslatitude"=dat.ml$abslatitude,"fit"=pred_sprich$fit) 

############################
####### MAINLAND AM ########
############################

gam.mod.AM <- gam(AM ~ s(abslatitude),family=nb(link="log"), data = dat.ml) 
summary(gam.mod.AM)

# check assumptions
gam.check(gam.mod.AM)
Check.disp(gam.mod.AM,dat)

pred.AM <- predict.gam(gam.mod.AM,type = "response", se = TRUE) 
pred.AM <- data.frame("abslatitude"=dat.ml$abslatitude,"fit"= pred.AM$fit,"se.fit"=pred.AM$se.fit) %>% mutate(myctype = "AM")

############################
####### MAINLAND EM ########
############################

gam.mod.EM <- gam(EM ~ s(abslatitude),family=nb(link="log"), data = dat.ml) 
summary(gam.mod.EM)

# check assumptions
gam.check(gam.mod.EM)
Check.disp(gam.mod.EM,dat)

pred.EM <- predict.gam(gam.mod.EM,type = "response", se = TRUE) 
pred.EM <- data.frame("abslatitude"=dat.ml$abslatitude,"fit"=pred.EM$fit,"se.fit"=pred.EM$se.fit) %>% mutate(myctype = "EM")

############################
####### MAINLAND ORC #######
############################

gam.mod.ORC <- gam(ORC ~ s(abslatitude),family=nb(link="log"), data = dat.ml) 
summary(gam.mod.ORC)

# check assumptions
gam.check(gam.mod.ORC)
Check.disp(gam.mod.ORC,dat)

pred.ORC <- predict.gam(gam.mod.ORC,type = "response", se = TRUE) 
pred.ORC <- data.frame("abslatitude"=dat.ml$abslatitude,"fit"=pred.ORC$fit,"se.fit"=pred.ORC$se.fit) %>% mutate(myctype = "ORC")

############################
####### MAINLAND NM ########
############################

gam.mod.NM <- gam(NM ~ s(abslatitude),family=nb(link="log"), data = dat.ml) 
summary(gam.mod.NM)

# check assumptions
gam.check(gam.mod.NM)
Check.disp(gam.mod.NM,dat)

pred.NM <- predict.gam(gam.mod.NM,type = "response", se = TRUE) 
pred.NM <- data.frame("abslatitude"=dat.ml$abslatitude,"fit"=pred.NM$fit,"se.fit"=pred.NM$se.fit) %>% mutate(myctype = "NM")

############################
########## PLOT ############
##### LAT BY MYC TYPE ######
############################

#pred.mainland <- rbind(pred.AM,pred.EM,pred.ORC,pred.NM)
pred.mainland <- rbind(pred.AM,pred.EM,pred.NM)

#dat.ml.cond <- dat.ml %>%
#  select(abslatitude, AM,EM,ORC,NM) %>%
#  gather(key="myctype", value="sprich", AM,EM,ORC,NM) 

dat.ml.cond <- dat.ml %>%
  select(abslatitude, AM,EM,NM) %>%
  gather(key="myctype", value="sprich", AM,EM,NM) 

# create a custom color scale
colScale <- scale_colour_manual(values=c("royalblue4", "royalblue3","darkgrey"))
fillScale <- scale_fill_manual(values=c("royalblue4", "royalblue3","darkgrey"))

#pred.mainland$myctype <- ordered(pred.mainland$myctype, levels = c("AM","EM","ORC","NM"))
#dat.ml.cond$myctype <- ordered(dat.ml.cond$myctype, levels = c("AM","EM","ORC","NM"))

pred.mainland$myctype <- ordered(pred.mainland$myctype, levels = c("AM","EM","NM"))
dat.ml.cond$myctype <- ordered(dat.ml.cond$myctype, levels = c("AM","EM","NM"))

lat.myctype <-
ggplot(pred.mainland,aes(x =abslatitude,y=fit,color =myctype, fill =myctype))+
  geom_line(size=1) +
  geom_point(data=dat.ml.cond, aes(x = abslatitude,y=sprich, color =factor(myctype)), alpha=0.3,size=4)+ 
  geom_ribbon(aes(ymin = fit-se.fit, ymax = fit+se.fit), alpha = 0.5) + 
  xlab("Absolute latitude") +
  ylab("Species richness")+
  theme_classic(base_size = 25)+
  ylim(0,4000)+
  colScale+
  fillScale+
  theme(legend.position = 'none')+
  #theme(legend.justification=c(1,1), legend.position=c(1,1))+
  guides(fill = FALSE) +
  guides(color = guide_legend(title="Mycorrhizal \nType",override.aes=list(fill =NA,size =3, alpha =0.7,linetype = c(0, 0, 0))))+
  theme(axis.text.x = element_text(size =20),axis.text.y = element_text(angle = 45,size=20))

# write out
png("figures/Myc_LatbyMycType.jpg", width=10, height= 10, units='in', res=300)
lat.myctype
dev.off()

############################
###### PREDICT EXP IS ######
####### ALL ISLANDS ########
############################

dat.is.min <- dat %>% filter(entity_class=="Island") %>% select(c('entity_ID',"abslatitude"))

pred_sprich <- predict.gam(gam.mod_sprich,newdata = dat.is.min,type = "response", se = TRUE) %>%
  as.data.frame() %>%
  select(fit)
pred_sprich_df <- cbind(dat.is.min,pred_sprich) %>% rename(sprich_exp = fit)

pred_AM <- predict.gam(gam.mod.AM,newdata = dat.is.min,type = "response", se = TRUE) %>%
  as.data.frame() %>%
  select(fit)
pred_AM_df <- cbind(dat.is.min,pred_AM) %>% rename(AM_exp = fit)

pred_EM <- predict.gam(gam.mod.EM,newdata = dat.is.min,type = "response", se = TRUE) %>%
  as.data.frame() %>%
  select(fit)
pred_EM_df <- cbind(dat.is.min,pred_EM) %>% rename(EM_exp = fit)

pred_ORC <- predict.gam(gam.mod.ORC,newdata = dat.is.min,type = "response", se = TRUE) %>%
  as.data.frame() %>%
  select(fit)
pred_ORC_df <- cbind(dat.is.min,pred_ORC) %>% rename(ORC_exp = fit)

pred_NM <- predict.gam(gam.mod.NM,newdata = dat.is.min,type = "response", se = TRUE) %>%
  as.data.frame() %>%
  select(fit)
pred_NM_df <- cbind(dat.is.min,pred_NM) %>% rename(NM_exp = fit)

pred_is.dat <- dat %>%
  filter(entity_class=="Island") %>%
  left_join(pred_sprich_df, by= c('entity_ID','abslatitude')) %>%
  left_join(pred_AM_df, by= c('entity_ID','abslatitude')) %>%
  left_join(pred_EM_df, by= c('entity_ID','abslatitude')) %>%
  left_join(pred_ORC_df, by= c('entity_ID','abslatitude')) %>%
  left_join(pred_NM_df, by= c('entity_ID','abslatitude')) %>%
  mutate_at(c('AM_exp','EM_exp','ORC_exp', 'NM_exp','sprich_exp'), as.integer) %>%
  mutate(propAM_exp = AM_exp/(AM_exp + EM_exp + ORC_exp + NM_exp)) %>%
  mutate(propEM_exp = EM_exp/(AM_exp + EM_exp + ORC_exp + NM_exp)) %>%
  mutate(propORC_exp = ORC_exp/(AM_exp + EM_exp + ORC_exp + NM_exp))

# write out
saveRDS(pred_is.dat,"data/GAMexp_native_myc_latitude_data_2023.RDS")

############################
####### MAIN MODELS ########
############################

############################
######## CREATE DATA #######
############################

# Read data and calc debts
full.dat <- dat2 %>%
  select(c("entity_ID", "dist", "area", "elev_range")) 

# version 1; debt & C_debt neg to 0, >1 to 1:
pred_is.dat.shrink <- readRDS("data/GAMexp_native_myc_latitude_data_2023.RDS") %>%
  select(-area) %>%
  mutate(sprich = AM + EM + ORC + NM, sprich_exp = AM_exp + EM_exp + ORC_exp + NM_exp) %>%
  mutate(AMdiff = AM_exp - AM, EMdiff = EM_exp - EM, ORCdiff = ORC_exp - ORC, NMdiff = NM_exp - NM, sprichdiff = sprich_exp - sprich) %>%
  mutate(AMdebt = (AMdiff/AM_exp), EMdebt = (EMdiff/EM_exp), ORCdebt = (ORCdiff/ORC_exp), NMdebt = (NMdiff/NM_exp), Tdebt = (sprichdiff/sprich_exp))  %>%
  mutate(AMdebt = ifelse(AMdebt < 0, 0, AMdebt)) %>% mutate(EMdebt = ifelse(EMdebt <0, 0, EMdebt)) %>% mutate(ORCdebt = ifelse(ORCdebt <0, 0, ORCdebt)) %>% mutate(NMdebt = ifelse(NMdebt <0, 0, NMdebt)) %>% mutate(Tdebt = ifelse(Tdebt <0, 0, Tdebt)) %>%
  mutate(AMdebt = ifelse(AMdebt > 1, 1, AMdebt)) %>% mutate(EMdebt = ifelse(EMdebt >1, 1, EMdebt)) %>% mutate(ORCdebt = ifelse(ORCdebt >1, 1, ORCdebt)) %>% mutate(NMdebt = ifelse(NMdebt >1, 1, NMdebt)) %>% mutate(Tdebt = ifelse(Tdebt >1, 1, Tdebt)) %>%
  mutate(C_AMdebt = (AMdiff/sprichdiff), C_EMdebt = (EMdiff/sprichdiff), C_ORCdebt = (ORCdiff/sprichdiff), C_NMdebt = (NMdiff/sprichdiff)) %>% 
  mutate(C_AMdebt = ifelse(C_AMdebt < 0, 0, C_AMdebt)) %>% mutate(C_EMdebt = ifelse(C_EMdebt <0, 0, C_EMdebt)) %>% mutate(C_ORCdebt = ifelse(C_ORCdebt <0, 0, C_ORCdebt)) %>% mutate(C_NMdebt = ifelse(C_NMdebt <0, 0, C_NMdebt)) %>%
  mutate(C_AMdebt = ifelse(C_AMdebt > 1, 1, C_AMdebt)) %>% mutate(C_EMdebt = ifelse(C_EMdebt >1, 1, C_EMdebt)) %>% mutate(C_ORCdebt = ifelse(C_ORCdebt >1, 1, C_ORCdebt)) %>% mutate(C_NMdebt = ifelse(C_NMdebt >1, 1, C_NMdebt)) %>%
  left_join(full.dat, by = "entity_ID") 

# version 2; remove negatives: 4% data lost
pred_is.dat.drop <- readRDS("data/GAMexp_native_myc_latitude_data_2023.RDS") %>%
  select(-area) %>%
  mutate(sprich = AM + EM + ORC + NM, sprich_exp = AM_exp + EM_exp + ORC_exp + NM_exp) %>%
  mutate(AMdiff = AM_exp - AM, EMdiff = EM_exp - EM, ORCdiff = ORC_exp - ORC, NMdiff = NM_exp - NM, sprichdiff = sprich_exp - sprich) %>%
  mutate(AMdebt = (AMdiff/AM_exp), EMdebt = (EMdiff/EM_exp), ORCdebt = (ORCdiff/ORC_exp), NMdebt = (NMdiff/NM_exp), Tdebt = (sprichdiff/sprich_exp))%>%
  mutate(C_AMdebt = (AMdiff/sprichdiff), C_EMdebt = (EMdiff/sprichdiff), C_ORCdebt = (ORCdiff/sprichdiff), C_NMdebt = (NMdiff/sprichdiff)) %>%
  filter(AMdiff > 0 & EMdiff >0 & ORCdiff > 0 & NMdiff > 0 & sprichdiff > 0) %>%
  filter(AMdebt > 0 & EMdebt >0 & ORCdebt > 0 & NMdebt > 0 & Tdebt > 0) %>%
  filter(C_AMdebt > 0 & C_EMdebt > 0 & C_ORCdebt > 0 & C_NMdebt > 0) %>%
  left_join(full.dat, by = "entity_ID") 

############################
######### PREP DATA ########
############################

# ! choose one
pred_is.dat <- pred_is.dat.shrink
pred_is.dat <- pred_is.dat.drop

# write out
debt <- pred_is.dat.shrink %>% select(c("entity_ID","Tdebt","sprichdiff","dist","area","elev_range","latitude","longitude","abslatitude","sprich_exp", "temp","prec"))
saveRDS(debt,"data/debt_native_myc_latitude_data_2023.RDS")

pred_is.dat.alld <- pred_is.dat %>% 
  select(c('entity_ID','AMdebt','EMdebt','ORCdebt','NMdebt')) %>%
  gather(key = "myctype", value = "debt", AMdebt, EMdebt, ORCdebt, NMdebt) %>%
  mutate(myctype = case_when(myctype=="AMdebt" ~ "AM",                                   
                             myctype=="EMdebt" ~ "EM", 
                             myctype=="ORCdebt" ~ "ORC", 
                             myctype=="NMdebt" ~ "NM")) 

pred_is.dat.allcd <- pred_is.dat %>% 
  select(c('entity_ID','C_AMdebt','C_EMdebt','C_ORCdebt','C_NMdebt')) %>%
  gather(key = "myctype", value = "debt.c", C_AMdebt, C_EMdebt, C_ORCdebt, C_NMdebt)%>%
  mutate(myctype = case_when(myctype == "C_AMdebt" ~ "AM",                                   
                             myctype == "C_EMdebt" ~ "EM", 
                             myctype == "C_ORCdebt" ~ "ORC", 
                             myctype == "C_NMdebt" ~ "NM"))

pred_is.dat.all.diff <- pred_is.dat %>% 
  select(c('entity_ID','sprich','latitude','longitude','abslatitude','AMdiff','EMdiff','ORCdiff','NMdiff','dist','area','elev_range', 'temp','prec')) %>%
  gather(key = "myctype", value = "diff", AMdiff, EMdiff, ORCdiff, NMdiff) %>%
  mutate(myctype = case_when(myctype == "AMdiff" ~ "AM",                                   
                             myctype == "EMdiff" ~ "EM", 
                             myctype == "ORCdiff" ~ "ORC", 
                             myctype == "NMdiff" ~ "NM")) 

pred_is.dat.all.exp <- pred_is.dat %>% 
  select(c('entity_ID','AM_exp','EM_exp','ORC_exp','NM_exp')) %>%
  gather(key = "myctype", value = "exp", AM_exp, EM_exp, ORC_exp,NM_exp) %>%
  mutate(myctype = case_when(myctype == "AM_exp" ~ "AM",                                   
                             myctype == "EM_exp" ~ "EM", 
                             myctype == "ORC_exp" ~ "ORC", 
                             myctype == "NM_exp" ~ "NM")) 


pred_is.dat.all.obs <- pred_is.dat %>% 
  select(c('entity_ID', 'AM', 'EM', 'ORC', 'NM')) %>%
  gather(key = "myctype", value = "obs", AM, EM, ORC, NM) 

pred_is.dat.all.T <- pred_is.dat %>% select(entity_ID, sprichdiff)

pred_is.dat.all <- pred_is.dat.all.diff %>%
  left_join(pred_is.dat.all.exp, by = c("myctype", "entity_ID")) %>%
  left_join(pred_is.dat.all.obs, by = c("myctype", "entity_ID")) %>%
  left_join(pred_is.dat.alld, by = c("myctype", "entity_ID")) %>%
  left_join(pred_is.dat.allcd, by = c("myctype", "entity_ID")) %>%
  left_join(pred_is.dat.all.T, by = c("entity_ID")) %>%
  mutate(debt.weights = exp, debt.c.weights = abs(sprichdiff)) %>%
  mutate(myctype = as.factor(myctype))

pred_is.dat.all <- within(pred_is.dat.all, myctype <- relevel(myctype, ref = "NM"))

############################
#### LAT RELATIONSHIPS #####
############################

# check correlations between abslatitude and area, dist, elev_range
lat.dat <- pred_is.dat.all %>%                                                                                         
  select(c("abslatitude", "area", "dist", "elev_range"))                                
lat.cor <- as.matrix(cor(lat.dat))  

mod <- lm(abslatitude ~ area, lat.dat)
mod <- lm(abslatitude ~ dist, lat.dat)
mod <- lm(abslatitude ~ elev_range, lat.dat)

summary(mod)

Area.lat.plot <- 
  ggplot(data = pred_is.dat.all, aes(x = abslatitude, y = area), color = "darkgrey") +
  geom_point(alpha = 0.1, size = 5) +
  geom_smooth(method = "loess", color = "aquamarine4", fill = "aquamarine4") +
  theme_classic(base_size = 40) +
  ylab("Area") +
  xlab("Absolute latitude") +
  theme(legend.position = "none", axis.text.y = element_text(angle = 45)) +
  ylim(-2,2) 

Dist.lat.plot <- 
  ggplot(data = pred_is.dat.all, aes(x = abslatitude, y = dist), color = "darkgrey") +
  geom_point(alpha = 0.1, size = 5) +
  geom_smooth(method = "loess", color = "aquamarine4", fill = "aquamarine4") +
  theme_classic(base_size = 40) +
  ylab("Distance") +
  xlab("Absolute latitude") +
  theme(legend.position = "none", axis.text.y = element_text(angle = 45)) +
  ylim(0,2) 

Elev.lat.plot <- 
  ggplot(data = pred_is.dat.all, aes(x = abslatitude, y = elev_range), color = "darkgrey") +
  geom_point(alpha = 0.1, size = 5) +
  geom_smooth(method = "loess", color = "aquamarine4", fill = "aquamarine4") +
  theme_classic(base_size = 40) +
  ylab("Elevation range") +
  xlab("Absolute latitude") +
  theme(legend.position = "none", axis.text.y = element_text(angle = 45)) +
  ylim(-2,2) 

# write out
png("figures/Lat_area.jpg", width = 10, height = 10, units = 'in', res = 300)
Area.lat.plot
dev.off()

png("figures/Lat_dist.jpg", width = 10, height = 10, units = 'in', res = 300)
Dist.lat.plot
dev.off()

png("figures/Lat_elev.jpg", width = 10, height = 10, units = 'in', res = 300)
Elev.lat.plot
dev.off()

############################
####### DEFICIT PLOT #######
############################

mod <- lm(abslatitude ~ sprichdiff, pred_is.dat.all)
summary(mod)

Deficit.lat.plot <- 
  ggplot(data = pred_is.dat.all, aes(x = abslatitude, y = sprichdiff), color = "darkgrey") +
  geom_point(alpha = 0.1, size = 5) +
  geom_smooth(method = "loess", color = "black", fill = "black") +
  theme_classic(base_size = 30) +
  ylab("Species deficit") +
  xlab("Absolute latitude") +
  theme(legend.position = "none", axis.text.y = element_text(angle = 45)) +
  ylim(0,4000) 

# write out
png("figures/Lat_deficit.jpg", width = 10, height = 10, units = 'in', res = 300)
Deficit.lat.plot
dev.off()

############################
######### CUT DATA #########
############################

# set vars
x_var = pred_is.dat.all$abslatitude
myc_var= pred_is.dat.all$myctype

# !choose one
y_var = pred_is.dat.all$debt
#y_var = pred_is.dat.all$debt.c

df <- data.frame("xvar" = x_var,"yvar" = y_var,"myctype"=myc_var)

# create binned y-values for the x-axis
quantiles_for_cutting <- quantile(df$xvar,seq(0,1,.20))

# cut the data
df$cuts_raw <- cut(df$xvar,breaks = quantiles_for_cutting, include.lowest = T)

# calculate the average value within each bin of the x-axis data
mean_per_cut <- df %>% group_by(cuts_raw) %>%
  summarize(mean_cut_xval = mean(xvar))

#now use the "mean_per_cut" to define our new cuts
df$cuts_labeled <- as.numeric(as.character(cut(df$xvar,breaks = quantiles_for_cutting,
                                               labels = mean_per_cut$mean_cut_xval, include.lowest = T)))

#now calculate the mean response variable values within each bin: 95% CIs assuming a normal distribution here
aggregated_data <- df %>% group_by(cuts_raw,cuts_labeled,myctype) %>%
  summarize(mean_y = mean(yvar),
            sd_y = sd(yvar),
            n_y = length(yvar)) %>%
  mutate(se_y = sd_y/sqrt(n_y),
         low95CI_y = mean_y-1.96*se_y,
         high95CI_y = mean_y+1.96*se_y)

# !choose one
debt.aggregated_data <- aggregated_data
#debtc.aggregated_data <- aggregated_data

############################
######### ONE MODEL ########
############################

############################
######## WITHIN DEBT #######
############################

# cbind drop & shrink
#pred.allcatd <- glm(cbind(diff,obs) ~ abslatitude*myctype + area + dist + elev_range  + prec + (1|entity_ID),family = binomial(link="logit"), data = pred_is.dat.all) 
#rac <- Spat.cor.rep(pred.allcatd,pred_is.dat.all,2000)
#pred.allcatd.rac <- glm(cbind(diff,obs) ~ abslatitude*myctype + area + dist +elev_range + prec + rac,family = binomial(link="logit"), data = pred_is.dat.all) 
#summary(pred.allcatd.rac)
#anova(pred.allcatd.rac)

# **FINAL**: glm drop & shrink
pred.allcatd <- glm(debt ~ abslatitude*myctype + area + dist + elev_range  + prec + (1|entity_ID),weights = debt.weights, data = pred_is.dat.all) 
summary(pred.allcatd)
rac <- Spat.cor.rep(pred.allcatd,pred_is.dat.all,2000)
pred.allcatd.rac  <- glm(debt ~ abslatitude*myctype + area + dist + elev_range  + prec + rac +(1|entity_ID),weights = debt.weights, data = pred_is.dat.all) 
summary(pred.allcatd.rac)

# glm drop & shrink poly
#pred.allcatd <- glm(debt ~ poly(abslatitude,2,raw = TRUE)*myctype + area + dist +elev_range  + prec + (1|entity_ID),weights = debt.weights, data = pred_is.dat.all) 
#rac <- Spat.cor.rep(pred.allcatd,pred_is.dat.all,2000)
#pred.allcatd.rac  <- glm(debt ~ poly(abslatitude,2,raw = TRUE)*myctype + area + dist +elev_range  + prec + rac +(1|entity_ID),weights = debt.weights, data = pred_is.dat.all) 
#summary(pred.allcatd.rac)
#anova(pred.allcatd.rac)

# glm diagnostics:
par(mfrow=c(3,2))
# homogenetity of variance:
plot(fitted(pred.allcatd.rac) ~ resid(pred.allcatd.rac, type = "pearson"))
# independence:
plot(pred_is.dat.all$area ~ resid(pred.allcatd.rac, type = "pearson"))
plot(pred_is.dat.all$dist ~ resid(pred.allcatd.rac, type = "pearson"))
plot(pred_is.dat.all$elev_range ~ resid(pred.allcatd.rac, type = "pearson"))
boxplot(resid(pred.allcatd.rac, type = "pearson") ~ pred_is.dat.all$myctype)
# do not look for normality:
# outliers:
plot(cooks.distance(pred.allcatd.rac), type ="h")
# check dispersion:
Check.disp(pred.allcatd.rac, pred_is.dat.all)

############################
########## DEBT C ##########
############################

# glm drop & shrink
#pred.allcatcd <- glm(debt.c ~ abslatitude*myctype + area + dist +elev_range  + prec + (1|entity_ID),weights = debt.c.weights, data = pred_is.dat.all) 
#rac <- Spat.cor.rep(pred.allcatcd,pred_is.dat.all,2000)
#pred.allcatcd.rac  <- glm(debt.c ~ abslatitude*myctype + area + dist +elev_range  + prec + rac +(1|entity_ID),weights = debt.c.weights, data = pred_is.dat.all) 
#summary(pred.allcatcd.rac)
#anova(pred.allcatcd.rac)

# *FINAL*: glm drop & shrink: polynomial
pred.allcatcd <- glm(debt.c ~ poly(abslatitude,2,raw = TRUE)*myctype + area + dist + elev_range + prec + (1|entity_ID),weights = debt.c.weights, data = pred_is.dat.all) 
rac <- Spat.cor.rep(pred.allcatcd,pred_is.dat.all,2000)
pred.allcatcd.rac  <- glm(debt.c ~ poly(abslatitude,2,raw = TRUE)*myctype + area + dist + elev_range  + prec + rac +(1|entity_ID),weights = debt.c.weights, data = pred_is.dat.all) 
summary(pred.allcatcd.rac)

# glm diagnostics:
par(mfrow=c(3,2))
# homogenetity of variance:
plot(fitted(pred.allcatcd.rac) ~ resid(pred.allcatcd.rac, type = "pearson"))
# independence:
plot(pred_is.dat.all$area ~ resid(pred.allcatcd.rac, type = "pearson"))
plot(pred_is.dat.all$dist ~ resid(pred.allcatcd.rac, type = "pearson"))
plot(pred_is.dat.all$elev_range ~ resid(pred.allcatcd.rac, type = "pearson"))
boxplot(resid(pred.allcatcd.rac, type = "pearson") ~ pred_is.dat.all$myctype)
# do not look for normality:
# outliers:
plot(cooks.distance(pred.allcatcd.rac), type ="h")
# check dispersion:
Check.disp(pred.allcatcd.rac, pred_is.dat.all)

############################
########### PLOT ###########
##### DEBT:FULL MODEL ######
############################

new.dat.AM <- with(pred_is.dat.all, expand.grid(abslatitude= seq(min(abslatitude), max(abslatitude), length = nrow(pred_is.dat.all)))) %>% 
  mutate(area = mean(pred.allcatd.rac$model$area), dist = mean(pred.allcatd.rac$model$dist),
         elev_range = mean(pred.allcatd.rac$model$elev_range), prec = mean(pred.allcatd.rac$model$prec), rac = mean(pred.allcatd.rac$model$rac), myctype="AM", entity_ID=pred_is.dat.all$entity_ID)
pred.AM <- predict.glm(pred.allcatd.rac,newdata = new.dat.AM, type = "response", se = TRUE, newdata.guaranteed = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude=new.dat.AM$abslatitude) 

new.dat.EM <- with(pred_is.dat.all, expand.grid(abslatitude= seq(min(abslatitude), max(abslatitude), length = nrow(pred_is.dat.all)))) %>% 
  mutate(area = mean(pred.allcatd.rac$model$area), dist = mean(pred.allcatd.rac$model$dist),
         elev_range = mean(pred.allcatd.rac$model$elev_range), prec = mean(pred.allcatd.rac$model$prec), rac = mean(pred.allcatd.rac$model$rac), myctype = "EM", entity_ID=pred_is.dat.all$entity_ID)
pred.EM <- predict.glm(pred.allcatd.rac,newdata = new.dat.EM, type = "response", se = TRUE, newdata.guaranteed = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude=new.dat.EM$abslatitude) 

new.dat.ORC <- with(pred_is.dat.all, expand.grid(abslatitude= seq(min(abslatitude), max(abslatitude), length = nrow(pred_is.dat.all)))) %>% 
  mutate(area = mean(pred.allcatd.rac$model$area), dist = mean(pred.allcatd.rac$model$dist),
         elev_range = mean(pred.allcatd.rac$model$elev_range), prec = mean(pred.allcatd.rac$model$prec), rac = mean(pred.allcatd.rac$model$rac), myctype = "ORC", entity_ID=pred_is.dat.all$entity_ID)
pred.ORC <- predict.glm(pred.allcatd.rac,newdata = new.dat.ORC, type = "response", se = TRUE, newdata.guaranteed = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude=new.dat.ORC$abslatitude) 

new.dat.NM <- with(pred_is.dat.all, expand.grid(abslatitude= seq(min(abslatitude), max(abslatitude), length = nrow(pred_is.dat.all)))) %>% 
  mutate(area = mean(pred.allcatd.rac$model$area), dist = mean(pred.allcatd.rac$model$dist),
         elev_range = mean(pred.allcatd.rac$model$elev_range), prec = mean(pred.allcatd.rac$model$prec), rac = mean(pred.allcatd.rac$model$rac), myctype = "NM", entity_ID=pred_is.dat.all$entity_ID)
pred.NM <- predict.glm(pred.allcatd.rac,newdata = new.dat.NM, type = "response", se = TRUE, newdata.guaranteed = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude=new.dat.NM$abslatitude) 

allcatd.plot <- 
ggplot() +
  #AM section
  geom_line(data = pred.AM, mapping = aes(x = abslatitude, y = fit), color ="royalblue4")+
  geom_ribbon(data = pred.AM, aes(x = abslatitude, ymin=fit-se.fit, ymax = fit + se.fit), fill = "royalblue4", alpha = 0.5) +
  #geom_point(data = pred_is.dat.all %>% filter(myctype=="AM"), aes(x = abslatitude, y=debt),color ="royalblue4", alpha= 0.3, size=5) +
  geom_point(data = debt.aggregated_data %>% filter(myctype=="AM"),aes(x = cuts_labeled-2, y = mean_y),color = "royalblue4",size = 4,shape = 16, alpha = 0.8) +
  geom_errorbar(data = debt.aggregated_data %>% filter(myctype=="AM"),aes(x = cuts_labeled-2, y = mean_y, ymin = low95CI_y,ymax =high95CI_y),color = "royalblue4", width=4,size=2, alpha = 0.8) +
  #EM section
  geom_line(data = pred.EM, mapping = aes(x = abslatitude, y = fit), color ="royalblue3")+
  geom_ribbon(data = pred.EM, aes(x = abslatitude, ymin=fit-se.fit, ymax = fit + se.fit), fill = "royalblue3", alpha = 0.5) +
  #geom_point(data = pred_is.dat.all %>% filter(myctype=="EM"), aes(x = abslatitude, y=debt),color ="royalblue3", alpha= 0.3, size=5) +
  geom_point(data = debt.aggregated_data %>% filter(myctype=="EM"),aes(x = cuts_labeled+2, y = mean_y),color = "royalblue3",size = 4,shape = 16, alpha = 0.8) +
  geom_errorbar(data = debt.aggregated_data %>% filter(myctype=="EM"),aes(x = cuts_labeled+2, y = mean_y, ymin = low95CI_y,ymax =high95CI_y),color = "royalblue3", width=4,size=2, alpha = 0.8) +
  #ORC section
  #geom_line(data = pred.ORC, mapping = aes(x = abslatitude, y = fit), color ="darkorchid3")+
  #geom_ribbon(data = pred.ORC, aes(x = abslatitude, ymin=fit-se.fit, ymax = fit + se.fit), fill = "darkorchid3", alpha = 0.5) +
  #geom_point(data = pred_is.dat.all %>% filter(myctype=="ORC"), aes(x = abslatitude, y=debt),color ="darkorchid3", alpha= 0.3, size=5) +
  #geom_point(data = debt.aggregated_data %>% filter(myctype=="ORC"),aes(x = cuts_labeled, y = mean_y),color = "darkorchid3",size = 4,shape = 16, alpha = 0.8) +
  #geom_errorbar(data = debt.aggregated_data %>% filter(myctype=="ORC"),aes(x = cuts_labeled, y = mean_y, ymin = low95CI_y,ymax =high95CI_y),color = "darkorchid3", width=4,size=2, alpha = 0.8)+
  #NM section
  geom_line(data = pred.NM, mapping = aes(x = abslatitude, y = fit), color ="darkgrey")+
  geom_ribbon(data = pred.NM, aes(x = abslatitude, ymin=fit-se.fit, ymax = fit + se.fit), fill = "darkgrey", alpha= 0.5) +
  #geom_point(data = pred_is.dat.all %>% filter(myctype=="NM"), aes(x = abslatitude, y=debt),color ="darkgrey", alpha= 0.3, size=5) +
  geom_point(data = debt.aggregated_data %>% filter(myctype=="NM"),aes(x = cuts_labeled+4, y = mean_y),color = "darkgrey",size = 4,shape = 16, alpha = 0.8) +
  geom_errorbar(data = debt.aggregated_data %>% filter(myctype=="NM"),aes(x = cuts_labeled+4, y = mean_y, ymin = low95CI_y,ymax =high95CI_y),color = "darkgrey", width=4, size=2, alpha = 0.8)+
  theme_classic(base_size = 40) +
  #geom_abline(intercept = 0, slope = 0, linetype="dashed")+
  ylab("Proportional species deficit") +
  xlab("Absolute latitude") +
  ylim(0.4,1.05)

# write out
png("figures/Myc_LatBox_withindebt_fullmodelshrink.jpg", width = 10, height = 10, units = 'in', res = 300)
allcatd.plot
dev.off()

############################
########### PLOT ###########
#### C DEBT:FULL MODEL #####
############################

new.dat.AM <- with(pred_is.dat.all, expand.grid(abslatitude = seq(min(abslatitude), max(abslatitude), length = nrow(pred_is.dat.all)))) %>% 
  mutate(area = mean(pred.allcatcd.rac$model$area), dist = mean(pred.allcatcd.rac$model$dist),
         elev_range = mean(pred.allcatcd.rac$model$elev_range), prec = mean(pred.allcatcd.rac$model$prec), rac = mean(pred.allcatcd.rac$model$rac), myctype = "AM", entity_ID=pred_is.dat.all$entity_ID)
pred.AM <- predict.glm(pred.allcatcd.rac,newdata = new.dat.AM, type = "response", se = TRUE, newdata.guaranteed = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude=new.dat.AM$abslatitude) 

new.dat.EM <- with(pred_is.dat.all, expand.grid(abslatitude= seq(min(abslatitude), max(abslatitude), length = nrow(pred_is.dat.all)))) %>% 
  mutate(area = mean(pred.allcatcd.rac$model$area), dist = mean(pred.allcatcd.rac$model$dist),
         elev_range = mean(pred.allcatcd.rac$model$elev_range), prec = mean(pred.allcatcd.rac$model$prec), rac = mean(pred.allcatcd.rac$model$rac), myctype = "EM", entity_ID=pred_is.dat.all$entity_ID)
pred.EM <- predict.glm(pred.allcatcd.rac,newdata = new.dat.EM, type = "response", se = TRUE, newdata.guaranteed = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude=new.dat.EM$abslatitude) 

new.dat.ORC <- with(pred_is.dat.all, expand.grid(abslatitude= seq(min(abslatitude), max(abslatitude), length = nrow(pred_is.dat.all)))) %>% 
  mutate(area = mean(pred.allcatcd.rac$model$area), dist = mean(pred.allcatcd.rac$model$dist),
         elev_range = mean(pred.allcatcd.rac$model$elev_range), prec = mean(pred.allcatcd.rac$model$prec), rac = mean(pred.allcatcd.rac$model$rac), myctype = "ORC", entity_ID=pred_is.dat.all$entity_ID)
pred.ORC <- predict.glm(pred.allcatcd.rac,newdata = new.dat.ORC, type = "response", se = TRUE, newdata.guaranteed = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude=new.dat.ORC$abslatitude) 

new.dat.NM <- with(pred_is.dat.all, expand.grid(abslatitude= seq(min(abslatitude), max(abslatitude), length = nrow(pred_is.dat.all)))) %>% 
  mutate(area = mean(pred.allcatcd.rac$model$area), dist = mean(pred.allcatcd.rac$model$dist),
         elev_range = mean(pred.allcatcd.rac$model$elev_range), prec = mean(pred.allcatcd.rac$model$prec), rac = mean(pred.allcatcd.rac$model$rac), myctype = "NM", entity_ID=pred_is.dat.all$entity_ID)
pred.NM <- predict.glm(pred.allcatcd.rac,newdata = new.dat.NM, type = "response", se = TRUE, newdata.guaranteed = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude=new.dat.NM$abslatitude) 

allcatcd.plot <- 
ggplot() +
  #AM section
  geom_line(data = pred.AM, mapping = aes(x = abslatitude, y = fit), color ="royalblue4")+
  geom_ribbon(data = pred.AM, aes(x = abslatitude, ymin=fit-se.fit, ymax = fit + se.fit), fill = "royalblue4", alpha= 0.5) +
  geom_point(data = pred_is.dat.all %>% filter(myctype=="AM"), aes(x = abslatitude, y=debt.c),color ="royalblue4", alpha= 0.3, size=2) +
  #geom_point(data = debtc.aggregated_data %>% filter(myctype=="AM"),aes(x = cuts_labeled, y = mean_y),color = "royalblue4",size = 1,shape = 15) +
  #geom_errorbar(data = debtc.aggregated_data %>% filter(myctype=="AM"),aes(x = cuts_labeled, y = mean_y, ymin = low95CI_y,ymax =high95CI_y),color = "royalblue4", width=3,size=1.5) +
  #EM section
  geom_line(data = pred.EM, mapping = aes(x = abslatitude, y = fit), color ="royalblue3")+
  geom_ribbon(data = pred.EM, aes(x = abslatitude, ymin=fit-se.fit, ymax = fit + se.fit), fill = "royalblue3", alpha= 0.5) +
  geom_point(data = pred_is.dat.all %>% filter(myctype=="EM"), aes(x = abslatitude, y=debt.c),color ="royalblue3", alpha= 0.3, size=2) +
  #geom_point(data = debtc.aggregated_data %>% filter(myctype=="EM"),aes(x = cuts_labeled, y = mean_y),color = "royalblue3",size = 1,shape = 15) +
  #geom_errorbar(data = debtc.aggregated_data %>% filter(myctype=="EM"),aes(x = cuts_labeled, y = mean_y, ymin = low95CI_y,ymax =high95CI_y),color = "royalblue3", width=3,size=1.5) +
  #ORC section
  #geom_line(data = pred.ORC, mapping = aes(x = abslatitude, y = fit), color ="darkorchid3")+
  #geom_ribbon(data = pred.ORC, aes(x = abslatitude, ymin=fit-se.fit, ymax = fit + se.fit), fill = "darkorchid3", alpha= 0.5) +
  #geom_point(data = pred_is.dat.all %>% filter(myctype=="ORC"), aes(x = abslatitude, y=debt.c),color ="darkorchid3", alpha= 0.3, size=2) +
  #geom_point(data = debtc.aggregated_data %>% filter(myctype=="ORC"),aes(x = cuts_labeled, y = mean_y),color = "darkorchid3",size = 1,shape = 15) +
  #geom_errorbar(data = debtc.aggregated_data %>% filter(myctype=="ORC"),aes(x = cuts_labeled, y = mean_y, ymin = low95CI_y,ymax =high95CI_y),color = "darkorchid3", width=3,size=1.5) +
  #NM section
  geom_line(data = pred.NM, mapping = aes(x = abslatitude, y = fit), color ="darkgrey")+
  geom_ribbon(data = pred.NM, aes(x = abslatitude, ymin=fit-se.fit, ymax = fit + se.fit), fill = "darkgrey", alpha= 0.5) +
  geom_point(data = pred_is.dat.all %>% filter(myctype=="NM"), aes(x = abslatitude, y=debt.c),color ="darkgrey", alpha= 0.3, size=2) +
  #geom_point(data = debtc.aggregated_data %>% filter(myctype=="NM"),aes(x = cuts_labeled, y = mean_y),color = "darkgrey",size = 1,shape = 15) +
  #geom_errorbar(data = debtc.aggregated_data %>% filter(myctype=="NM"),aes(x = cuts_labeled, y = mean_y, ymin = low95CI_y,ymax =high95CI_y),color = "darkgrey", width=3,size=1.5) +
  theme_classic(base_size = 15) +
  #geom_abline(intercept = 0, slope = 0, linetype="dashed")+
  ylab("Contribution deficit") +
  xlab("Absolute latitude") +
  ylim(0,1.25)

# write out
png("figures/Myc_LatPoly_contdebt_fullmodel_shrink.jpg", width = 6, height = 6, units ='in', res = 300)
allcatcd.plot
dev.off()

############################
###### MODEL PER MYC #######
############################

pred_is.dat.AM <- pred_is.dat.all %>% filter(myctype == "AM")
pred_is.dat.EM <- pred_is.dat.all %>% filter(myctype == "EM")
pred_is.dat.ORC <- pred_is.dat.all %>% filter(myctype == "ORC")
pred_is.dat.NM <- pred_is.dat.all %>% filter(myctype == "NM")

############################
########## DEBT C ##########
############################

# AM Poly
pred.allcatcd.AM <- glm(debt.c ~ poly(abslatitude,2,raw = TRUE)*area + poly(abslatitude,2,raw = TRUE)*dist +poly(abslatitude,2,raw = TRUE)*elev_range + poly(abslatitude,2,raw = TRUE)*prec, weights = debt.c.weights, data = pred_is.dat.AM) 
rac <- Spat.cor.rep(pred.allcatcd.AM, pred_is.dat.AM, 2000)
pred.allcatcd.AM.rac  <- glm(debt.c ~ poly(abslatitude,2,raw = TRUE)*area + poly(abslatitude,2,raw = TRUE)*dist +poly(abslatitude,2,raw = TRUE)*elev_range + poly(abslatitude,2,raw = TRUE)*prec + rac , weights = debt.c.weights, data = pred_is.dat.AM) 
summary(pred.allcatcd.AM.rac)
pred.allcatcd.AM.rac.min  <- glm(debt.c ~ poly(abslatitude,2,raw = TRUE):area + poly(abslatitude,2,raw = TRUE)*dist + poly(abslatitude,2,raw = TRUE):prec + rac , weights = debt.c.weights, data = pred_is.dat.AM) 
summary(pred.allcatcd.AM.rac.min)

# EM Poly
pred.allcatcd.EM <- glm(debt.c ~ poly(abslatitude,2,raw = TRUE)*area + poly(abslatitude,2,raw = TRUE)*dist +poly(abslatitude,2,raw = TRUE)*elev_range + poly(abslatitude,2,raw = TRUE)*prec, weights = debt.c.weights, data = pred_is.dat.EM) 
rac <- Spat.cor.rep(pred.allcatcd.EM, pred_is.dat.EM, 2000)
pred.allcatcd.EM.rac  <- glm(debt.c ~ poly(abslatitude,2,raw = TRUE)*area + poly(abslatitude,2,raw = TRUE)*dist +poly(abslatitude,2,raw = TRUE)*elev_range + poly(abslatitude,2,raw = TRUE)*prec + rac, weights = debt.c.weights, data = pred_is.dat.EM) 
summary(pred.allcatcd.EM.rac)
pred.allcatcd.EM.rac.min  <- glm(debt.c ~  poly(abslatitude,2,raw = TRUE):prec + rac, weights = debt.c.weights, data = pred_is.dat.EM) 
summary(pred.allcatcd.EM.rac.min)

# ORC Poly
pred.allcatcd.ORC <- glm(debt.c ~ poly(abslatitude,2,raw = TRUE)*area + poly(abslatitude,2,raw = TRUE)*dist +poly(abslatitude,2,raw = TRUE)*elev_range + poly(abslatitude,2,raw = TRUE)*prec, weights = debt.c.weights, data = pred_is.dat.ORC) 
rac <- Spat.cor.rep(pred.allcatcd.ORC, pred_is.dat.ORC, 2000)
pred.allcatcd.ORC.rac  <- glm(debt.c ~ poly(abslatitude,2,raw = TRUE)*area + poly(abslatitude,2,raw = TRUE)*dist +poly(abslatitude,2,raw = TRUE)*elev_range + poly(abslatitude,2,raw = TRUE)*prec + rac, weights = debt.c.weights, data = pred_is.dat.ORC) 
summary(pred.allcatcd.ORC.rac)
pred.allcatcd.ORC.rac.min  <- glm(debt.c ~ poly(abslatitude,2,raw = TRUE)+ rac, weights = debt.c.weights, data = pred_is.dat.ORC) 
summary(pred.allcatcd.ORC.rac.min)

# NM Poly
pred.allcatcd.NM <- glm(debt.c ~ poly(abslatitude,2,raw = TRUE)*area + poly(abslatitude,2,raw = TRUE)*dist +poly(abslatitude,2,raw = TRUE)*elev_range + poly(abslatitude,2,raw = TRUE)*prec,weights = debt.c.weights, data = pred_is.dat.NM) 
rac <- Spat.cor.rep(pred.allcatcd.NM, pred_is.dat.NM, 2000)
pred.allcatcd.NM.rac  <- glm(debt.c ~ poly(abslatitude,2,raw = TRUE)*area + poly(abslatitude,2,raw = TRUE)*dist +poly(abslatitude,2,raw = TRUE)*elev_range + poly(abslatitude,2,raw = TRUE)*prec + rac, weights = debt.c.weights, data = pred_is.dat.NM) 
summary(pred.allcatcd.NM.rac)
pred.allcatcd.NM.rac.min  <- glm(debt.c ~ poly(abslatitude,2,raw = TRUE)*dist + poly(abslatitude,2,raw = TRUE):prec + rac, weights = debt.c.weights, data = pred_is.dat.NM) 
summary(pred.allcatcd.NM.rac.min)

############################
########### PLOT ###########
#### C DEBT:MYC MODELS #####
############################

# set cut value
cut_tol <- 0.25

# create a custom color scale
colScale <- scale_colour_manual(values=c("darkgoldenrod1", "darkorchid"))
fillScale <- scale_fill_manual(values=c("darkgoldenrod1", "darkorchid"))

############################
######### AM PLOTS #########
############################

############################
########## AM:lat ##########
############################

mod <- pred.allcatcd.AM.rac.min
dat <- pred_is.dat.AM

abslatitude.range <- with(dat, expand.grid(abslatitude = seq(min(abslatitude), max(abslatitude), length = nrow(dat)))) %>%
  mutate(dist = mean(mod$model$dist), prec = mean(mod$model$prec), area = mean(mod$model$area), rac = mean(mod$model$rac), entity_ID = dat$entity_ID)
new.dat <- expand.grid(abslatitude = abslatitude.range$abslatitude) %>%
  left_join(abslatitude.range, by = c("abslatitude")) 

pred.AM.abslat <- predict.glm(mod, newdata = new.dat, type = "response", se = TRUE, newdata.guaranteed = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude = new.dat$abslatitude) 

AM.lat.plot <- 
  ggplot(data = pred.AM.abslat,mapping = aes(x = abslatitude, y = fit),color ="darkgrey") +
  geom_line()+
  geom_ribbon(data = pred.AM.abslat, aes(x = abslatitude, ymin=fit-se.fit, ymax = fit + se.fit), fill = "darkgrey", alpha= 0.5) +
  #geom_point(data = dat, aes(x = abslatitude, y = debt.c),fill = "darkgrey", alpha= 0.5)+
  theme_classic(base_size = 40) +
  #ylab("Contribution deficit") +
  #xlab("Absolute latitude") +
  ylab("")+ xlab("")+
  colScale+
  fillScale+
  theme(legend.position = "none")

png("figures/Myc_LatPoly_contdebt_AMmodel_lat_shrink.jpg", width = 6, height = 6, units ='in', res = 300)
AM.lat.plot
dev.off()

############################
########## AM:dist #########
############################

mod <- pred.allcatcd.AM.rac.min
dat <- pred_is.dat.AM

dist.range <- data.frame(dist = quantile(mod$data$dist, c(cut_tol, 1-cut_tol)), level =c ("near", "far")) 
abslatitude.range <- with(dat, expand.grid(abslatitude = seq(min(abslatitude), max(abslatitude), length = nrow(dat)))) %>%
  mutate(prec = mean(mod$model$prec), area = mean(mod$model$area), rac = mean(mod$model$rac), entity_ID = dat$entity_ID)
new.dat <- expand.grid(abslatitude = abslatitude.range$abslatitude, dist = dist.range$dist) %>%
  left_join(abslatitude.range, by = c("abslatitude")) 
pred.AM.dist <- predict.glm(mod, newdata = new.dat, type = "response", se = TRUE, newdata.guaranteed = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude = new.dat$abslatitude, dist=new.dat$dist) %>%
  left_join(dist.range, by = "dist")

dat.tol <- dat %>%
  filter(dist < dist.range$dist[1]| dist > dist.range$dist[2]) %>%
  mutate(level = ifelse(dist < dist.range$dist[1], "near","far")) %>%
  select(entity_ID, abslatitude, debt.c,level) 

dat.tol.far <- dat.tol %>%
  filter(level == "far")

dat.tol.near <- dat.tol %>%
  filter(level == "near")

AM.dist.plot <- 
  ggplot(data = pred.AM.dist, aes(x = abslatitude, y = fit, color = level, fill = level)) +
  geom_line() +
  geom_ribbon(data = pred.AM.dist, aes(x = abslatitude, ymin=fit-se.fit, ymax = fit + se.fit), alpha = 0.5) +
  #geom_point(data = dat.tol.far, aes(x = abslatitude, y = debt.c, color = level, fill = level), color = "darkgoldenrod1", alpha = 0.5)+
  #geom_point(data = dat.tol.near, aes(x = abslatitude, y = debt.c, color = level, fill = level), color = "darkorchid", alpha = 0.5)+
  theme_classic(base_size = 40) +
  #ylab("Contribution deficit") +
  #xlab("Absolute latitude") +
  ylab("")+ xlab("")+
  colScale+
  fillScale+
  theme(legend.position = "none")+
  #theme(legend.position = c(0.8, 0.85))+
  guides(color = FALSE) +
  guides(fill = guide_legend(title="Island distance"), override.aes = list(fill = NA))

png("figures/Myc_LatPoly_contdebt_AMmodel_dist_shrink.jpg", width = 6, height = 6, units ='in', res = 300)
AM.dist.plot
dev.off()

############################
########## AM:prec #########
############################

mod <- pred.allcatcd.AM.rac.min
dat <- pred_is.dat.AM

prec.range <- data.frame(prec = quantile(mod$data$prec, c(cut_tol, 1-cut_tol)), level =c ("near", "far")) 
abslatitude.range <- with(dat, expand.grid(abslatitude = seq(min(abslatitude), max(abslatitude), length = nrow(dat)))) %>%
  mutate(dist = mean(mod$model$dist), area = mean(mod$model$area), rac = mean(mod$model$rac), entity_ID = dat$entity_ID)
new.dat <- expand.grid(abslatitude = abslatitude.range$abslatitude, prec = prec.range$prec) %>%
  left_join(abslatitude.range, by = c("abslatitude")) 
pred.AM.prec <- predict.glm(mod, newdata = new.dat, type = "response", se = TRUE, newdata.guaranteed = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude = new.dat$abslatitude, prec=new.dat$prec) %>%
  left_join(prec.range, by = "prec")

dat.tol <- dat %>%
  filter(prec < prec.range$prec[1]| prec > prec.range$prec[2]) %>%
  mutate(level = ifelse(prec < prec.range$prec[1], "low","high")) %>%
  select(entity_ID, abslatitude, debt.c,level) 

dat.tol.high <- dat.tol %>%
  filter(level == "high")

dat.tol.low <- dat.tol %>%
  filter(level == "low")

AM.prec.plot <- 
  ggplot(data = pred.AM.prec, aes(x = abslatitude, y = fit, color = level, fill = level)) +
  geom_line() +
  geom_ribbon(data = pred.AM.prec, aes(x = abslatitude, ymin=fit-se.fit, ymax = fit + se.fit), alpha = 0.5) +
  #geom_point(data = dat.tol.high, aes(x = abslatitude, y = debt.c, color = level, fill = level), color = "darkgoldenrod1", alpha = 0.5)+
  #geom_point(data = dat.tol.low, aes(x = abslatitude, y = debt.c, color = level, fill = level), color = "darkorchid", alpha = 0.5)+
  theme_classic(base_size = 40) +
  #ylab("Contribution deficit") +
  #xlab("Absolute latitude") +
  ylab("")+ xlab("")+
  colScale+
  fillScale+
  theme(legend.position = "none")+
  #theme(legend.position = c(0.8, 0.85))+
  guides(color = FALSE) +
  guides(fill = guide_legend(title="Island precipitation"), override.aes = list(fill = NA))

png("figures/Myc_LatPoly_contdebt_AMmodel_prec_shrink.jpg", width = 6, height = 6, units ='in', res = 300)
AM.prec.plot
dev.off()

############################
########## AM:area #########
############################

mod <- pred.allcatcd.AM.rac.min
dat <- pred_is.dat.AM

area.range <- data.frame(area = quantile(mod$data$area, c(cut_tol, 1-cut_tol)), level =c ("near", "far")) 
abslatitude.range <- with(dat, expand.grid(abslatitude = seq(min(abslatitude), max(abslatitude), length = nrow(dat)))) %>%
  mutate(dist = mean(mod$model$dist), prec = mean(mod$model$prec), rac = mean(mod$model$rac), entity_ID = dat$entity_ID)
new.dat <- expand.grid(abslatitude = abslatitude.range$abslatitude, area = area.range$area) %>%
  left_join(abslatitude.range, by = c("abslatitude")) 
pred.AM.area <- predict.glm(mod, newdata = new.dat, type = "response", se = TRUE, newdata.guaranteed = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude = new.dat$abslatitude, area=new.dat$area) %>%
  left_join(area.range, by = "area")

dat.tol <- dat %>%
  filter(area < area.range$area[1]| area > area.range$area[2]) %>%
  mutate(level = ifelse(area < area.range$area[1], "small","large")) %>%
  select(entity_ID, abslatitude, debt.c,level) 

dat.tol.large <- dat.tol %>%
  filter(level == "large")

dat.tol.small <- dat.tol %>%
  filter(level == "small")

AM.area.plot <- 
  ggplot(data = pred.AM.area, aes(x = abslatitude, y = fit, color = level, fill = level)) +
  geom_line() +
  geom_ribbon(data = pred.AM.area, aes(x = abslatitude, ymin=fit-se.fit, ymax = fit + se.fit), alpha = 0.5) +
  #geom_point(data = dat.tol.large, aes(x = abslatitude, y = debt.c, color = level, fill = level), color = "darkgoldenrod1", alpha = 0.5)+
  #geom_point(data = dat.tol.small, aes(x = abslatitude, y = debt.c, color = level, fill = level), color = "darkorchid", alpha = 0.5)+
  theme_classic(base_size = 40) +
  #ylab("Contribution deficit") +
  #xlab("Absolute latitude") +
  ylab("")+ xlab("")+
  colScale+
  fillScale+
  theme(legend.position = "none")+
  #theme(legend.position = c(0.8, 0.85))+
  guides(color = FALSE) +
  guides(fill = guide_legend(title="Island area"), override.aes = list(fill = NA))

png("figures/Myc_LatPoly_contdebt_AMmodel_area_shrink.jpg", width = 6, height = 6, units ='in', res = 300)
AM.area.plot
dev.off()

############################
######### EM PLOTS #########
############################

############################
########## EM:prec #########
############################

mod <- pred.allcatcd.EM.rac.min
dat <- pred_is.dat.EM

prec.range <- data.frame(prec = quantile(mod$data$prec, c(cut_tol, 1-cut_tol)), level =c ("near", "far")) 
abslatitude.range <- with(dat, expand.grid(abslatitude = seq(min(abslatitude), max(abslatitude), length = nrow(dat)))) %>%
  mutate(rac = mean(mod$model$rac), entity_ID = dat$entity_ID)
new.dat <- expand.grid(abslatitude = abslatitude.range$abslatitude, prec = prec.range$prec) %>%
  left_join(abslatitude.range, by = c("abslatitude")) 
pred.EM.prec <- predict.glm(mod, newdata = new.dat, type = "response", se = TRUE, newdata.guaranteed = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude = new.dat$abslatitude, prec=new.dat$prec) %>%
  left_join(prec.range, by = "prec")

dat.tol <- dat %>%
  filter(prec < prec.range$prec[1]| prec > prec.range$prec[2]) %>%
  mutate(level = ifelse(prec < prec.range$prec[1], "low","high")) %>%
  select(entity_ID, abslatitude, debt.c,level) 

dat.tol.high <- dat.tol %>%
  filter(level == "high")

dat.tol.low <- dat.tol %>%
  filter(level == "low")

EM.prec.plot <- 
  ggplot(data = pred.EM.prec, aes(x = abslatitude, y = fit, color = level, fill = level)) +
  geom_line() +
  geom_ribbon(data = pred.EM.prec, aes(x = abslatitude, ymin=fit-se.fit, ymax = fit + se.fit), alpha = 0.5) +
  #geom_point(data = dat.tol.high, aes(x = abslatitude, y = debt.c, color = level, fill = level), color = "darkgoldenrod1", alpha = 0.5)+
  #geom_point(data = dat.tol.low, aes(x = abslatitude, y = debt.c, color = level, fill = level), color = "darkorchid", alpha = 0.5)+
  theme_classic(base_size = 40) +
  #ylab("Contribution deficit") +
  #xlab("Absolute latitude") +
  ylab("")+ xlab("")+
  colScale+
  fillScale+
  theme(legend.position = "none")+
  #theme(legend.position = c(0.8, 0.85))+
  guides(color = FALSE) +
  guides(fill = guide_legend(title="Island precipitation"), override.aes = list(fill = NA))

png("figures/Myc_LatPoly_contdebt_EMmodel_prec_shrink.jpg", width = 6, height = 6, units ='in', res = 300)
EM.prec.plot
dev.off()

############################
######### ORC PLOTS ########
############################

############################
######### ORC:lat ##########
############################

mod <- pred.allcatcd.ORC.rac.min
dat <- pred_is.dat.ORC

abslatitude.range <- with(dat, expand.grid(abslatitude = seq(min(abslatitude), max(abslatitude), length = nrow(dat)))) %>%
  mutate(prec = mean(mod$model$prec), rac = mean(mod$model$rac), entity_ID = dat$entity_ID)
new.dat <- expand.grid(abslatitude = abslatitude.range$abslatitude) %>%
  left_join(abslatitude.range, by = c("abslatitude")) 

pred.ORC.abslat <- predict.glm(mod, newdata = new.dat, type = "response", se = TRUE, newdata.guaranteed = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude = new.dat$abslatitude) 

ORC.lat.plot <- 
  ggplot(data = pred.ORC.abslat,mapping = aes(x = abslatitude, y = fit),color ="darkgrey") +
  geom_line()+
  geom_ribbon(data = pred.ORC.abslat, aes(x = abslatitude, ymin=fit-se.fit, ymax = fit + se.fit), fill = "darkgrey", alpha= 0.5) +
  #geom_point(data = dat, aes(x = abslatitude, y = debt.c),fill = "darkgrey", alpha= 0.5)+
  theme_classic(base_size = 40) +
  #ylab("Contribution deficit") +
  #xlab("Absolute latitude") +
  ylab("")+ xlab("")+
  colScale+
  fillScale+
  theme(legend.position = "none")

png("figures/Myc_LatPoly_contdebt_ORCmodel_lat_shrink.jpg", width = 6, height = 6, units ='in', res = 300)
ORC.lat.plot
dev.off()

############################
######### NM PLOTS #########
############################

############################
########## NM:lat ##########
############################

mod <- pred.allcatcd.NM.rac.min
dat <- pred_is.dat.NM

abslatitude.range <- with(dat, expand.grid(abslatitude = seq(min(abslatitude), max(abslatitude), length = nrow(dat)))) %>%
  mutate(dist = mean(mod$model$dist), prec= mean(mod$model$prec), rac = mean(mod$model$rac), entity_ID = dat$entity_ID)
new.dat <- expand.grid(abslatitude = abslatitude.range$abslatitude) %>%
  left_join(abslatitude.range, by = c("abslatitude")) 

pred.NM.abslat <- predict.glm(mod, newdata = new.dat, type = "response", se = TRUE, newdata.guaranteed = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude = new.dat$abslatitude) 

NM.lat.plot <- 
  ggplot(data = pred.NM.abslat,mapping = aes(x = abslatitude, y = fit),color ="darkgrey") +
  geom_line()+
  geom_ribbon(data = pred.NM.abslat, aes(x = abslatitude, ymin=fit-se.fit, ymax = fit + se.fit), fill = "darkgrey", alpha= 0.5) +
  #geom_point(data = dat, aes(x = abslatitude, y = debt.c),fill = "darkgrey", alpha= 0.5)+
  theme_classic(base_size = 40) +
  #ylab("Contribution deficit") +
  #xlab("Absolute latitude") +
  ylab("")+ xlab("")+
  colScale+
  fillScale+
  theme(legend.position = "none")

png("figures/Myc_LatPoly_contdebt_NMmodel_lat_shrink.jpg", width = 6, height = 6, units ='in', res = 300)
NM.lat.plot
dev.off()

############################
########## NM:dist #########
############################

mod <- pred.allcatcd.NM.rac.min
dat <- pred_is.dat.NM

dist.range <- data.frame(dist = quantile(mod$data$dist, c(cut_tol, 1-cut_tol)), level =c ("near", "far")) 
abslatitude.range <- with(dat, expand.grid(abslatitude = seq(min(abslatitude), max(abslatitude), length = nrow(dat)))) %>%
  mutate(prec = mean(mod$model$prec), rac = mean(mod$model$rac), entity_ID = dat$entity_ID)
new.dat <- expand.grid(abslatitude = abslatitude.range$abslatitude, dist = dist.range$dist) %>%
  left_join(abslatitude.range, by = c("abslatitude")) 
pred.NM.dist <- predict.glm(mod, newdata = new.dat, type = "response", se = TRUE, newdata.guaranteed = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude = new.dat$abslatitude, dist=new.dat$dist) %>%
  left_join(dist.range, by = "dist")

dat.tol <- dat %>%
  filter(dist < dist.range$dist[1]| dist > dist.range$dist[2]) %>%
  mutate(level = ifelse(dist < dist.range$dist[1], "near","far")) %>%
  select(entity_ID, abslatitude, debt.c,level) 

dat.tol.far <- dat.tol %>%
  filter(level == "far")

dat.tol.near <- dat.tol %>%
  filter(level == "near")

NM.dist.plot <- 
  ggplot(data = pred.NM.dist, aes(x = abslatitude, y = fit, color = level, fill = level)) +
  geom_line() +
  geom_ribbon(data = pred.NM.dist, aes(x = abslatitude, ymin=fit-se.fit, ymax = fit + se.fit), alpha = 0.5) +
  #geom_point(data = dat.tol.far, aes(x = abslatitude, y = debt.c, color = level, fill = level), color = "darkgoldenrod1", alpha = 0.5)+
  #geom_point(data = dat.tol.near, aes(x = abslatitude, y = debt.c, color = level, fill = level), color = "darkorchid", alpha = 0.5)+
  theme_classic(base_size = 40) +
  #ylab("Contribution deficit") +
  #xlab("Absolute latitude") +
  ylab("")+ xlab("")+
  colScale+
  fillScale+
  theme(legend.position = "none")+
  #theme(legend.position = c(0.8, 0.85))+
  guides(color = FALSE) +
  guides(fill = guide_legend(title="Island distance"), override.aes = list(fill = NA))

png("figures/Myc_LatPoly_contdebt_NMmodel_dist_shrink.jpg", width = 6, height = 6, units ='in', res = 300)
NM.dist.plot
dev.off()

############################
########## NM:prec #########
############################

mod <- pred.allcatcd.NM.rac.min
dat <- pred_is.dat.NM

prec.range <- data.frame(prec = quantile(mod$data$prec, c(cut_tol, 1-cut_tol)), level =c ("low", "high")) 
abslatitude.range <- with(dat, expand.grid(abslatitude = seq(min(abslatitude), max(abslatitude), length = nrow(dat)))) %>%
  mutate(dist = mean(mod$model$dist), rac = mean(mod$model$rac), entity_ID = dat$entity_ID)
new.dat <- expand.grid(abslatitude = abslatitude.range$abslatitude, prec = prec.range$prec) %>%
  left_join(abslatitude.range, by = c("abslatitude")) 
pred.NM.prec <- predict.glm(mod, newdata = new.dat, type = "response", se = TRUE, newdata.guaranteed = TRUE) %>%
  as.data.frame() %>% 
  mutate(abslatitude = new.dat$abslatitude, prec=new.dat$prec) %>%
  left_join(prec.range, by = "prec")

dat.tol <- dat %>%
  filter(prec < prec.range$prec[1]| prec > prec.range$prec[2]) %>%
  mutate(level = ifelse(prec < prec.range$prec[1], "low","high")) %>%
  select(entity_ID, abslatitude, debt.c,level) 

dat.tol.high <- dat.tol %>%
  filter(level == "high")

dat.tol.low <- dat.tol %>%
  filter(level == "low")

NM.prec.plot <- 
  ggplot(data = pred.NM.prec, aes(x = abslatitude, y = fit, color = level, fill = level)) +
  geom_line() +
  geom_ribbon(data = pred.NM.prec, aes(x = abslatitude, ymin=fit-se.fit, ymax = fit + se.fit), alpha = 0.5) +
  #geom_point(data = dat.tol.high, aes(x = abslatitude, y = debt.c, color = level, fill = level), color = "darkgoldenrod1", alpha = 0.5)+
  #geom_point(data = dat.tol.low, aes(x = abslatitude, y = debt.c, color = level, fill = level), color = "darkorchid", alpha = 0.5)+
  theme_classic(base_size = 40) +
  #ylab("Contribution deficit") +
  #xlab("Absolute latitude") +
  ylab("")+ xlab("")+
  colScale+
  fillScale+
  theme(legend.position = "none")+
  #theme(legend.position = c(0.8, 0.85))+
  guides(color = FALSE) +
  guides(fill = guide_legend(title="Island precipitation"), override.aes = list(fill = NA))

png("figures/Myc_LatPoly_contdebt_NMmodel_prec_shrink.jpg", width = 6, height = 6, units ='in', res = 300)
NM.prec.plot
dev.off()
